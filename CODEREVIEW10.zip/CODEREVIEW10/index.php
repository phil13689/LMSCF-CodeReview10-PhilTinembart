<?php require_once 'actions/db_connect.php'; ?>

<!DOCTYPE html>
<html>
<head>
<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<!-- Bootstrap CSS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<link rel="stylesheet" href="index_style.css">
   <title>PHP CRUD</title>
  
</head>

<!--------------- #############################  NAVBAR ##################### ---------------------->

<nav id="nav" class="navbar navbar-expand-lg navbar-light bg-danger">
  <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul class="navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Shipping</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Pricing</a>
      </li>
    </ul>
  </div>
</nav>

<!------------------ #######################################  MAIN CONTENT ############################-------------------->

<body>
<div class="container">
<hr>
<div class ="manageUser">
   <a href= "create.php"><button type="button"  id="adding" class="btn btn-outline-danger btn-lg btn-block">Add Your Media, mate!</button></a>
<hr>
<table class="table table-dark">
  <thead class="thead-dark">
    <tr>
      <th scope="col">Title</th>
      <th scope="col">Cover</th>
      <th scope="col">Author</th>
      <th scope="col">ISBN</th>
      <th scope="col">Description</th>
      <th scope="col">Publish Date</th>
      <th scope="col">Publisher</th>
      <th scope="col">Type</th>
      <th scope="col"></th>
    </tr>
  </thead>





        <tbody>

            <?php
           $sql = "SELECT * FROM media";
           $result = $connect->query($sql);

            if($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                   echo  "<tr>
                       <td>" .$row['title']."</td>
                       <td><img src= ' " .$row['image']." ' width='100px'></td>
                       <td>" .$row['author']."</td>
                       <td>" .$row['ISBN']."</td>
                       <td><button type='button' class='btn btn-outline-danger' data-toggle='modal' data-target= '#staticBackdrop'>Description</button></td>
                       <td>" .$row['publish_date']."</td>
                       <td>" .$row['publisher']."</td>
                       <td>" .$row['type']."</td>
                       <td>
                           <a href='update.php?id=" .$row['id']."'><button type='button' id='green' class='btn btn-outline-success'>-> Edit <-</button></a>
                           <a href='delete.php?id=" .$row['id']."'><button type='button' class='btn btn-outline-danger'>! Delete !</button></a>
                       </td>
                   </tr>" ;
               }
           } else  {
               echo  "<tr><td colspan='5'><center>No Data Avaliable</center></td></tr>";
           }
            ?>
  <!-----------  ################################   MODAL ######################## ------->

  <!-- Modal -->
  <div class="modal fade" id="staticBackdrop" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Description</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <?php $sql = "SELECT * FROM media";
           $result = $connect->query($sql);

            if($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) { 
                    echo "<h6>" .$row['description']."</h6>";
                    }
                } else  {
                    echo  "<tr><td colspan='5'><center>No Data Avaliable</center></td></tr>";
                }?>  <!-------------------------- HELP!!! ------------------>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
 
<!----------------------------  ############################## MODAL END #########################  ---------------------->
           
       </tbody>
</table>
</div>
</div>

<!-----------           #######################################  FOOTER ####################  ----------------------------->

<nav id="foot" class="navbar navbar-expand-lg navbar-light bg-danger">
  <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <h3>2020 Philippe Tinembart</h3>
  </div>
</nav>

<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

</body>
</html>