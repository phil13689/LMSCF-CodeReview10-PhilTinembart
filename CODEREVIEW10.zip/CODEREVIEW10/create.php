<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<!-- Bootstrap CSS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

   <title>PHP CRUD  |  Add Media</title>

   <style type= "text/css">

        body{
            background-color: darkslategrey;
            background-image: url("https://cdn.pixabay.com/photo/2016/09/08/22/43/books-1655783_1280.jpg");
        }
        
        fieldset {
            margin: auto;
            margin-top: 100px;
            width: 50%;      
        }
        .backgrnd{
            background-color: darkgoldenrod;
            box-shadow: 10px 10px 15px black;
            
        }
        #nav{
           box-shadow: 2px 2px 10px black;
           background-image: url("https://cdn.pixabay.com/photo/2017/02/20/21/30/turquoise-2083986__480.jpg");
           font-weight: bold;
           padding-bottom: 2%;
       }

        table tr th {
            padding-top: 20px;
        }

        .buttons{
            display: inline;
            margin-bottom: 1%; 
        }
        .subins{
           display: row;
        }
        .insert{
            margin-right: 75%;
        }

        h3 {
            color: white;
            text-align: center;
            padding-top: 2%;
            text-shadow: 2px 2px 2px black;
        }
        
      
      

    </style>
</head>


<!----------------  ############################   MAIN CONTENT #######################  ---->

<body>
<div class="fs">
<fieldset>
        <div class="backgrnd">
        <legend><h3>Add Media</h3></legend>
        <form action="actions/a_create.php" method="post">
            <div class="buttons">
                <div class="subins">
                    <div class="insert"><button class="btn btn-info" type="submit">Insert Media</button></div>
                    <div class="back"><a href="index.php"><button class="btn btn-danger" type="button">Back</button></a></div>
                </div>
            </div>
        
            <table class="table table-striped" cellspacing="1" cellpadding="0">
                <tr>
                    
                    <td><input class="form-control" type="text" name="title" placeholder="Title" /></td></tr>
                <tr>
                    
                    <td><input class="form-control" type="text" name="image" placeholder="Cover" /></td></tr>
                <tr>
                    
                    <td><input class="form-control" type="text" name="author" placeholder="Author"/></td></tr>
                <tr>
                    
                    <td><input class="form-control" type="number" name="ISBN" placeholder="ISBN_Nr"/></td></tr>
                <tr>
                    
                    <td><input class="form-control" type="text" name="description" placeholder="Description"/></td></tr>
                <tr>
                    
                    <td><input class="form-control" type="text" name="publish_date" placeholder="publish_date"/></td></tr>
                <tr>
                    
                    <td><input class="form-control" type="text" name="publisher" placeholder="publisher"/></td></tr>
                <tr>
                    
                    <td><input class="form-control" type="text" name="type" placeholder="Type"/></td></tr>
                    </table>
                
            
        </form>
        </div>
</fieldset>
</div>
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

</body>
</html>

