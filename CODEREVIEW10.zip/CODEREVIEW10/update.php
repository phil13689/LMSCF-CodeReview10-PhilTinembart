<?php 

require_once 'actions/db_connect.php';

if ($_GET['id']) {
   $id = $_GET['id'];

   $sql = "SELECT * FROM media WHERE id = {$id}" ;
   $result = $connect->query($sql);

   $data = $result->fetch_assoc();

   $connect->close();

?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<!-- Bootstrap CSS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

   <title >Edit Media</title>

   <style type= "text/css">
        body{
            background-color: dimgrey;
            
        }

        fieldset {
            margin : auto;
            margin-top: 100px;
            width: 50%;
            

       }

       table  tr th {
           padding-top: 20px;
       }
       .title {
           display: flex;
           justify-content: center;
           font-weight: bold;
           color: white;
           text-shadow: 2px 2px 2px black;
        }
        button{
            box-shadow: 3px 3px 10px black;
        }
       legend{
           color: white;
           font-weight: bold;
       }
       th{
           color: white;
       }
   </style>

</head>
<body>

<fieldset>
    <div class="container">
    <div class="title">
    <div class="subtitle">
   <legend>Update Media</legend>
   </div>
   </div>

   <form action="actions/a_update.php"  method="post">
       <table class="table table-striped" cellspacing="0" cellpadding= "0">
           <tr>
               <th>Title</th>
               <td><input class="form-control" type="text"  name="title" placeholder ="Title" value="<?php echo $data['title'] ?>"  /></td>
           </tr >    
           <tr>
               <th>Cover</th>
               <td><input class="form-control" type= "text" name="image"  placeholder="Cover" value ="<?php echo $data['image'] ?>" /></td >
           </tr>
           <tr>
               <th >Author</th>
               <td><input class="form-control" type ="text" name= "author" placeholder= "Author" value= "<?php echo $data['author'] ?>" /></td>
           </tr>
           <tr>
               <th >ISBN</th>
               <td><input class="form-control" type ="number" name= "ISBN" placeholder= "ISBN" value= "<?php echo $data['ISBN'] ?>" /></td>
           </tr>
           <tr>
               <th >Description</th>
               <td><input class="form-control" type ="text" name= "description" placeholder= "description" value= "<?php echo $data['description'] ?>" /></td>
           </tr>
           <tr>
               <th >Publish Date</th>
               <td><input class="form-control" type ="text" name= "publish_date" placeholder= "Publish Date" value= "<?php echo $data['publish_date'] ?>" /></td>
           </tr>
           <tr>
               <th >Publisher</th>
               <td><input class="form-control" type ="text" name= "publisher" placeholder= "Publisher" value= "<?php echo $data['publisher'] ?>" /></td>
           </tr>
           <tr>
               <th >Type</th>
               <td><input class="form-control" type ="text" name= "type" placeholder= "type" value= "<?php echo $data['type'] ?>" /></td>
           </tr>
           
           <tr>
               <input type= "hidden" name= "id" value= "<?php echo $data['id']?>" />
               <td><button class="btn btn-lg btn-info" type="submit">Save Changes</button ></td>
               <td><a  href= "index.php"><button class="btn btn-lg btn-danger" type="button">Back</button ></a ></td >
           </tr>
       </table>
   </form >
   </div>
</fieldset >
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

</body >
</html >

<?php
}
?>